"use strict";

let itemsPhotos = document.getElementsByClassName("good-photo");

for (let i = 0; i < itemsPhotos.length; i++) {
    switch (i) {
        case 0:
            itemsPhotos[i].style.backgroundImage = 'url("./images/flower.jpg")';
            break;
        case 1:
            itemsPhotos[i].style.backgroundImage= 'url("./images/rose.jpg")'
            break;
        case 2:
            itemsPhotos[i].style.backgroundImage = 'url("./images/actinidia.jpg")';
            break;
        case 3:
            itemsPhotos[i].style.backgroundImage = 'url("./images/cedr.jpg")';
            break;
    }
}

let leftMenuItems = document.getElementsByClassName("none");

function showElem(id) {
    let elem = document.getElementById(id);
    if (elem.style.display ==="" || elem.style.display === "none") {
        elem.style.display = "block";
        for (let i = 0; i < leftMenuItems.length; i++)
            if (leftMenuItems[i] != elem)
                leftMenuItems[i].style.textDecoration = "none";
            else
                leftMenuItems[i].style.textDecoration = "underline";
    } else {
        elem.style.display = "none";
    }
}

let paginationElemList = document.getElementById("pagination").getElementsByTagName("button");
paginationElemList[0].style.fontSize = "25px";
for (let i = 0; i < paginationElemList.length; i++) {
    let cur_a = paginationElemList[i];
    cur_a.addEventListener("click", function() {
        for (let i = 0; i < paginationElemList.length; i++)
            paginationElemList[i].style.fontSize = "20px";
        cur_a.style.fontSize = "25px";
    });
}